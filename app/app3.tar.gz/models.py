from mixins import CRUDMixin
from flask.ext.login import UserMixin
from flask.ext.sqlalchemy import SQLAlchemy
from sqlalchemy.orm import relationship, backref

from app import db



ROLE_USER = 0
ROLE_ADMIN = 1

class User(UserMixin, CRUDMixin,  db.Model):
    id = db.Column(db.Integer, primary_key = True, unique=True)
    userid = db.Column(db.String(255), unique=True)
    email = db.Column(db.String(255), unique=True)
    password = db.Column(db.String(20))
    oldPassword = db.Column(db.String(20))
    changedPass = db.Column(db.Boolean)
    role = db.Column(db.SmallInteger, default=ROLE_USER)
    s1 = db.Column(db.Boolean)
    s2 = db.Column(db.Boolean)
    s3 = db.Column(db.Boolean)
    s4 = db.Column(db.Boolean)
    lastSeen = db.Column(db.String(255))
    nuevouser0 = db.Column(db.String(100))

    def __init__(self, email=None, userid=None, password=None, oldPassword = None, changedPass=False,
        s1=False, s2=False, s3=False, s4=False, role=None, nuevouser0 = None):
        self.email = email
        self.userid = userid
        self.password = password
        self.oldPassword = oldPassword
        self.changedPass = changedPass
        self.s1=s1
        self.s2=s2
        self.s3=s3
        self.s4=s4
        self.role=role	
	self.nuevouser0 = nuevouser0

    def is_admin(self):
        if self.role == 1:
            return True
        else:
            return False

    def is_active(self):
        return True

    def get_id(self):
        return unicode(self.id)

    def __repr__(self):
        return '<User %r>' % (self.email)



class Survey1(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sector = db.Column(db.String(100))
    autor = db.Column(db.String(25))
    original = db.Column(db.Boolean)
    nuevouser1 = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    user = db.relationship('User', uselist=False, backref='survey1')
    

    def __init__(self, sector=None, contacto=None, original=None, autor=None, nombrecontacto = None, correoc=None, comentarioc= None, nuevouser1=None):

        self.sector = sector
	self.autor = autor
	self.original = original
	self.nuevouser1 = nuevouser1


    def get_id(self):
        return unicode(self.id)



class Survey2(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    publicar = db.Column(db.String(25))
    internacional = db.Column(db.String(25))
    beneficios = db.Column(db.String(25))
    tipo = db.Column(db.String(25))
    plataforma = db.Column(db.String(255))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    user = db.relationship('User', uselist=False, backref='survey2')
    nuevouser2 = db.Column(db.String(100))

    def __init__(self, publicar=None, internacional=None, beneficios=None, tipo=None, plataforma=None, nuevouser2 = None):
        self.publicar = publicar
        self.internacional = internacional
        self.beneficios = beneficios
        self.tipo = tipo
	self.plataforma = plataforma
	self.nuevouser2 = nuevouser2

    def get_id(self):
        return unicode(self.id)



class Survey3(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    importancia = db.Column(db.String(25))
    potenciar = db.Column(db.String(25))
    frecuencia = db.Column(db.String(25))
    ciudad = db.Column(db.String(255))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    user = db.relationship('User', uselist=False, backref='survey3')
    nuevouser3 = db.Column(db.String(100))


    def __init__(self, importancia=None, potenciar=None, frecuencia=None, ciudad=None, nuevouser3 = None):
	self.importancia = importancia
	self.potenciar = potenciar
	self.frecuencia = frecuencia
	self.ciudad = ciudad
	self.nuevouser3 = nuevouser3

    def get_id(self):
        return unicode(self.id)


class Survey4(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    costos = db.Column(db.String(25))
    conforme = db.Column(db.String(25))   
    participar = db.Column(db.String(25))  
    difusion = db.Column(db.String(25)) 
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    user = db.relationship('User', uselist=False, backref='survey4')
    nuevouser4 = db.Column(db.String(100))



    def __init__(self,
        costos=None,
	conforme=None,
	participar=None,
	difusion=None,
        userid=None,
	nuevouser4=None):

        self.costos=costos
	self.conforme=conforme
	self.participar=participar
	self.difusion=difusion
        self.userid=userid
	self.nuevouser4 = nuevouser4

    def get_id(self):
        return unicode(self.id)
