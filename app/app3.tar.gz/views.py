#FLASK
from flask import abort, render_template, Response, flash, redirect, session
from flask import url_for, g, request, send_from_directory
#FLASK EXTENSIONS
from flask.ext.login import login_user, logout_user, current_user, login_required
from flask.ext.sqlalchemy import get_debug_queries
from flask.ext.mail import Mail
#LOCAL
from models import User, ROLE_USER, ROLE_ADMIN, Survey1, Survey2, Survey3, Survey4
from forms import LoginForm, RegistrationForm, Survey1Form, Survey2Form, Survey3Form
from forms import Survey4Form, NewPass, ForgotPasswordForm
from email import user_notification, forgot_password
from config import DATABASE_QUERY_TIMEOUT
from app import app, db, lm, mail, models
from decorators import admin_required
#OTHER
from  datetime import date, timedelta
import uuid

from flask import make_response


@app.route('/survey_1/', methods=['GET','POST'])
#@login_required
def survey_1():


	if current_user.is_authenticated():

		g.user = current_user
		form = Survey1Form(request.form)

		if form.validate_on_submit():
			survey = Survey1()
			form.populate_obj(survey)
			survey.nuevouser1 = g.user.email
			db.session.add(survey)

			g.user.s1 = True
			#g.user.lastSeen = date.today()
			db.session.commit()

			mailuser = User.query.filter_by(userid=g.user.userid).first().email
		
			sector = Survey1.query.filter_by(nuevouser1=mailuser).first().sector

			autor = Survey1.query.filter_by(nuevouser1=mailuser).first().autor

			nusuario = mailuser.split('@')[0]

			return render_template("dashboard.html", title="Home", sector = sector, autor = autor, nusuario = nusuario)

		return render_template('survey/Survey1.html', title='Encuesta', form=form, opt='auth')

	elif request.cookies.get('autor') or request.cookies.get('sector'):
		autorc = request.cookies.get('autor')
		sect = request.cookies.get('sector')
		return render_template("dashboard.html", title="Panel", sector = sect ,autor=autorc)

	else: 


		form = Survey1Form(request.form)

		if form.validate_on_submit():
			survey = Survey1()
			form.populate_obj(survey)

			if form.data['nuevouser'] == '':
				userid=userid=(str(uuid.uuid1()))

			else:
				userid=form.data['nuevouser']

			g.user.nuevouser0 = userid
			survey.nuevouser1 = userid
			db.session.add(survey)

			#g.user.s1 = True
			#g.user.lastSeen = date.today()
			db.session.commit()
			
			if survey.autor == 'S':
				
				
				if survey.sector == 'Dis':

					resp = make_response(render_template("dashboard.html", title="Panel", sector ='Dis',autor='S'))
    					resp.set_cookie('autor', 'S')
					resp.set_cookie('uid', userid)
					resp.set_cookie('sector', 'Dis')
    					return resp
					

				elif survey.sector == 'Cons':

					
					resp = make_response(render_template("dashboard.html", title="Panel", sector ='Cons',autor='S'))
    					resp.set_cookie('autor', 'S')
					resp.set_cookie('sector', 'Cons')
					resp.set_cookie('uid', userid)
    					return resp

				else :
	
					
					resp = make_response(render_template("dashboard.html", title="Panel", sector ='Otro',autor='S'))
    					resp.set_cookie('autor', 'S')
					resp.set_cookie('uid', userid)
    					return resp


			else:
				
				if survey.sector == 'Dis':

					
					resp = make_response(render_template("dashboard.html", title="Panel", sector ='Dis',autor='N'))
    					resp.set_cookie('autor', 'N')
					resp.set_cookie('sector', 'Dis')
					resp.set_cookie('uid', userid)
    					return resp

				elif survey.sector == 'Cons':

					
					resp = make_response(render_template("dashboard.html", title="Panel", sector ='Cons',autor='N'))
    					resp.set_cookie('autor', 'N')
					resp.set_cookie('sector', 'Cons')
					resp.set_cookie('uid', userid)
    					return resp

				elif survey.nuevouser1 != '':
					return render_template ("gracias.html", title='Gracias', info='S')

				else:
					return render_template ("gracias.html", title='Gracias', info='N')

		return render_template('survey/Survey1.html', title='Encuesta', form=form, opt='')
	

@app.route('/survey_2/', methods=['GET','POST'])
def survey_2():

	if current_user.is_authenticated():

		g.user = current_user
		if  g.user.s2 is False:
			form = Survey2Form(request.form)

			if form.validate_on_submit():
				survey = Survey2()
				form.populate_obj(survey)
				survey.user = g.user
				db.session.add(survey)

				g.user.s2 = True
				g.user.lastSeen = date.today()
				db.session.commit()
			
				g.user = current_user
				mailuser = User.query.filter_by(userid=g.user.userid).first().email
				surv1 = Survey1.query.filter_by(nuevouser1=mailuser).first()
				
				nusuario = mailuser.split('@')[0]
				
				if surv1 != None: 
					return render_template ("dashboard.html", title="Panel", sector = surv1.sector, autor=surv1.autor, nusuario = nusuario)
				else:
					return render_template ("dashboard.html", title="Panel", sector = '', autor='')
				

			return render_template('survey/Survey2.html', title='Encuesta Diseno', form=form )


	else: 

		form = Survey2Form(request.form)

		if form.validate_on_submit():
			survey = Survey2()
			form.populate_obj(survey)
			survey.nuevouser2 = request.cookies.get('uid')
			db.session.add(survey)
			db.session.commit()
			
			
			if request.cookies.get('autor') == 'S':

				resp = make_response(render_template("dashboard.html", title="Panel", sector ='DisOK', autor='S'))
				resp.set_cookie('sector', 'DisOK')
				return resp

			else:
				resp = make_response(render_template("gracias.html", title="Gracias"))
    				resp.set_cookie('autor', '', expires=0)
				resp.set_cookie('sector', '', expires=0)
				resp.set_cookie('uid', '', expires=0)
    				return resp

		return render_template('survey/Survey2.html', title='Encuesta Diseno', form=form )



@app.route('/survey_3/', methods=['GET','POST'])
def survey_3():
	
	if current_user.is_authenticated():

		g.user = current_user
		if g.user.s3 is False:

			form = Survey3Form(request.form)

			if form.validate_on_submit():
				survey = Survey3()
				form.populate_obj(survey)
				survey.user = g.user
				db.session.add(survey)

				g.user.s3 = True
				g.user.lastSeen = date.today()
				db.session.commit()

				g.user = current_user
				mailuser = User.query.filter_by(userid=g.user.userid).first().email
				surv1 = Survey1.query.filter_by(nuevouser1=mailuser).first()
				
				nusuario = mailuser.split('@')[0]
				
				if surv1 != None: 
					return render_template ("dashboard.html", title="Panel", sector = surv1.sector, autor=surv1.autor, nusuario = nusuario)
				else:
					return render_template ("dashboard.html", title="Panel", sector = '', autor='')

			return render_template('survey/Survey3.html', title='Encuesta Construccion', form=form )
	else:

		form = Survey3Form(request.form)

		if form.validate_on_submit():
			survey = Survey3()
			form.populate_obj(survey)
			survey.nuevouser3 = request.cookies.get('uid')
			db.session.add(survey)
			db.session.commit()
		
			if request.cookies.get('autor') == 'S':

				resp = make_response(render_template("dashboard.html", title="Panel", sector ='ConsOK', autor='S'))
				resp.set_cookie('sector', 'ConsOK')
				return resp

			else:
				resp = make_response(render_template("gracias.html", title="Gracias"))
    				resp.set_cookie('autor', '', expires=0)
				resp.set_cookie('sector', '', expires=0)
				resp.set_cookie('uid', '', expires=0)
    				return resp

		return render_template('survey/Survey3.html', title='Encuesta Construccion', form=form )

@app.route('/survey_4/', methods=['GET','POST'])
def survey_4():

	if current_user.is_authenticated():
		g.user = current_user
		if  g.user.s4 is False:
	
			form = Survey4Form(request.form)

			if form.validate_on_submit():

				survey = Survey4()
				form.populate_obj(survey)
				survey.user = g.user
				db.session.add(survey)

				g.user.s4 = True
				g.user.lastSeen = date.today()
				db.session.commit()
				
				
				
			 	mailuser = User.query.filter_by(userid=g.user.userid).first().email
				surv1 = Survey1.query.filter_by(nuevouser1=mailuser).first()
				
				nusuario = mailuser.split('@')[0]

				#logout_user()
				
				if surv1 != None: 

					if request.cookies.get('autor')=='SOK':
						return render_template ("dashboard.html", title="Panel", sector = surv1.sector, autor='SOK', nusuario = nusuario)

					else: 
						return render_template ("dashboard.html", title="Panel", sector = surv1.sector, autor=surv1.autor, nusuario = nusuario)
				else:
					return render_template ("dashboard.html", title="Panel", sector = '', autor='')

				

			return render_template('survey/Survey4.html', title='Encuesta Aplicacion', form=form)
	else:
		form = Survey4Form(request.form)

		if form.validate_on_submit():

			survey = Survey4()
			form.populate_obj(survey)
			survey.nuevouser4 = request.cookies.get('uid')
			db.session.add(survey)
			db.session.commit()
			

			if request.cookies.get('sector') == 'Dis':
				resp = make_response(render_template("dashboard.html", title="Panel", sector ='Dis', autor='SOK'))
				resp.set_cookie('autor', 'SOK')
				return resp

			elif request.cookies.get('sector') =='Cons':
				
				resp = make_response(render_template("dashboard.html", title="Panel", sector ='Cons', autor='SOK'))
				resp.set_cookie('autor', 'SOK')
				return resp
			else:
				resp = make_response(render_template("final.html", title="Gracias"))
	    			resp.set_cookie('autor', '', expires=0)
				resp.set_cookie('sector', '', expires=0)
				resp.set_cookie('uid', '', expires=0)
	    			return resp

		return render_template('survey/Survey4.html', title='Encuesta Aplicacion', form=form)
		


@app.route('/create_acct/' , methods=['GET','POST'])
def create_acct():
	form = RegistrationForm(request.form)
	if form.validate_on_submit():

		aut= request.cookies.get('autor')
		sec = request.cookies.get('sector')
		
		s1val=False
		s2val= False
		s3val =False
		s4val=False

		if request.cookies.get('uid')!=None:

			if aut=='SOK':
				s1val=True
				s4val=True

			if sec=='DisOK':
				s1val=True
				s2val=True

			elif sec=='ConsOK':
				s1val=True
				s3val=True
			
			user = User(email=form.email.data, password=form.password.data,
				oldPassword=form.password.data, userid=request.cookies.get('uid'), s1=s1val ,s2=s2val ,s3=s3val, s4=s4val)

		else: 	
			user = User(email=form.email.data, password=form.password.data,
				oldPassword=form.password.data, userid=(str(uuid.uuid1())))
		db.session.add(user)
		db.session.commit()
		login_user(user)
		#user_notification(user)
		
		mailuser = form.email.data
		nusuario = mailuser.split('@')[0]
			
		return render_template ("dashboard.html", title="Panel", sector = sec, autor=aut, nusuario = nusuario)
	return render_template('create_acct.html', title = "Create Account", form=form)

@app.route('/new_pass/' , methods=['GET','POST'])
def new_pass():
	form = NewPass(request.form)
	if form.validate_on_submit():
		user = g.user
		print form.data
		if user.password == form.data['password']:
				print 'I should raise a validation error'
				form.password.errors.append('You\'ve already used this password. Please choose a new password.')
		else:
				print 'user picked a different password'
				user.password = form.password.data
				user.changedPass = True
				db.session.commit()
				return redirect(url_for('index'))

	return render_template('new_pass.html', title='Update Password', form=form)

@app.route('/login/',methods=['GET','POST'])
def login():
	form = LoginForm(request.form)
	if form.validate_on_submit():
		user = form.get_user()
		login_user(user)
		user = g.user
		if current_user.is_admin():
			return redirect(url_for('admin'))
		
		else:
			return redirect(request.args.get("next") or url_for("dashboard"))
	return render_template('login.html', title="Login", form=form)

@app.route('/forgot_passwd/', methods=['GET', 'POST'])
def forgot_passwd():
	form = ForgotPasswordForm(request.form)
	if form.validate_on_submit():
		user = request.form['email']
		if User.query.filter_by(email=user).first():
			q = User.query.filter_by(email=user).first()
			forgot_password(user, q.password)
			return redirect(request.args.get("next") or url_for("login"))
		else:
			flash('Username not found')
			return redirect(request.args.get("next") or url_for("login"))
	return render_template ("forgot_passwd.html",
		title="Recuperacion de contrase&ntide;a",
		form=form)

@app.route('/')
@app.route('/index')
def index():

	if current_user.is_authenticated():
		g.user = current_user

		mailuser = User.query.filter_by(userid=g.user.userid).first().email
	
		surv1 = Survey1.query.filter_by(nuevouser1=mailuser).first()

		nusuario = mailuser.split('@')[0]

		if surv1 != None: 

			return render_template ("dashboard.html", title="Panel", sector = surv1.sector, autor=surv1.autor, nusuario = nusuario)

		else:

			return render_template ("dashboard.html", title="Panel", sector = '', autor='')

	else:
		return render_template ("index.html", title="Home")



@app.route('/dashboard/')
def dashboard():
	if current_user.is_authenticated():
		g.user = current_user
		mailuser = User.query.filter_by(userid=g.user.userid).first().email
		surv1 = Survey1.query.filter_by(nuevouser1=mailuser).first()

		nusuario = mailuser.split('@')[0]

		if surv1 != None: 
			return render_template ("dashboard.html", title="Panel", sector = surv1.sector, autor=surv1.autor, nusuario = nusuario)
		else:
			return render_template ("dashboard.html", title="Panel", sector = '', autor='')

	else:
		return render_template ("dashboard.html", title="Panel", sector ='', autor='')

		

@app.route('/gracias/')
def gracias():

	return render_template ("dashboard.html", title="Home")


@app.route('/consent/')
def consent():
	return render_template('consent.html', title = "Acuerdo")

@app.route('/propuesta/')
def propuesta():
	return render_template('propuesta.html', title = "Propuesta")

@app.route('/logouthtml/')
def logouthtml():
	return render_template('logout.html', title="Logout")

@lm.user_loader
def load_user(id):
	return User.query.get(int(id))

@app.before_request
def before_request():
	g.user = current_user

@app.route('/logout')
def logout():
	logout_user()
	#return redirect(url_for('index'))

	resp = make_response(redirect(url_for('index')))
    	resp.set_cookie('autor', '', expires=0)
	resp.set_cookie('sector', '', expires=0)
	resp.set_cookie('uid', '', expires=0)
    	return resp

@app.errorhandler(404)
def internal_error(error):
	return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

@app.after_request
def after_request(response):
	for query in get_debug_queries():
		if query.duration >= DATABASE_QUERY_TIMEOUT:
			app.logger.warning("SLOW QUERY: %s\nParameters: %s\nDuration: %fs\nContext: %s\n" % (query.statement, query.parameters, query.duration, query.context))
	return response

def flash_errors(form):
	for field, errors in form.errors.items():
		for error in errors:
			flash(u"Error in the %s field - %s" % (
			getattr(form, field).label.text,error
		))


@app.route('/admin')
@login_required
@admin_required
def admin():
	users = User.query.filter_by(role=0)
	return render_template('admin/index.html', title="Admin", users=users)

@app.route('/admin_survey1/')
@login_required
@admin_required
def admin_survey1():
	surveys = Survey1.query.all()
	return render_template('admin/partials/survey1.html', title='Admin Survey-1', surveys=surveys)

@app.route('/admin_survey2/')
@login_required
@admin_required
def admin_survey2():
	surveys = Survey2.query.all()
	return render_template('admin/partials/survey2.html', title='Admin Survey-2', surveys=surveys)

@app.route('/admin_survey3/')
@login_required
@admin_required
def admin_survey3():
	surveys = Survey3.query.all()
	return render_template('admin/partials/survey3.html', title='Admin Survey-3', surveys=surveys)

@app.route('/admin_survey4/')
@login_required
@admin_required
def admin_survey4():
	surveys = Survey4.query.all()
	return render_template('admin/partials/survey4.html', title='Admin Survey-4', surveys=surveys)

