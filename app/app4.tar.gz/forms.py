from flask.ext.wtf import Form, fields, validators, Required, Email, ValidationError, Length, Regexp
from wtforms import widgets
from models import User
from app import db


def validate_login(form, field):
    user = form.get_user()
    if user is None:
        raise validators.ValidationError('Usuario no valido')
    if user.password != form.password.data:
        raise validators.ValidationError('Clave no valida')




class LoginForm(Form):
    email = fields.TextField('Correo', validators=[Required(), Email()])
    password = fields.PasswordField('Clave', validators=[Required(), validate_login])

    def get_user(self):
        return db.session.query(User).filter_by(email=self.email.data).first()


class ForgotPasswordForm(Form):
    email = fields.TextField(validators=['Correo', Required(), Email()])

    def get_user(self):
        return db.session.query(User).filter_by(email=self.email.data).first()


class RegistrationForm(Form):
    email = fields.TextField('Correo', validators=[Required(), Email(), Regexp('[^@]+@[inacapmail]+\.[cl]+', message=('No pertenece a inacapmail'))])
    consent = fields.BooleanField(validators=[Required()])
    password = fields.PasswordField('Nueva Clave', [
        validators.Required(), validators.Length(min=8, max=20),
        validators.EqualTo('confirm', message='La clave debe coincidir')
    ])
    confirm = fields.PasswordField('Confirmar',validators=[Required()])

    def validate_email(self, field):
        if db.session.query(User).filter_by(email=self.email.data).count() > 0:
            raise validators.ValidationError('Correo duplicado')


class NewPass(Form):
    password = fields.PasswordField('Nueva Clave', [
        validators.Required(), validators.Length(min=8, max=20),
        validators.EqualTo('confirm', message='La clave debe coincidir')
    ])
    confirm = fields.PasswordField('Confirmar',validators=[Required()])


class Survey1Form(Form):

    sector = fields.RadioField('&iquest; Qu&eacute; sector se relaciona mejor con sus perspectivas laborales ?', choices=[('Ind', 'Industrial'),('Dis', 'Dise&ntilde;o'), ('Cons', 'Construccion'), ('Vent', 'Ventas'), ('TI', 'Informatica'), ('Inv', 'Investigacion'), ('O', 'Otro')], validators=[Required()])
    autor = fields.RadioField('&iquest; Ha sido usted autor o colaborador de algun proyecto de dise&ntilde;o o construcci&oacute;n ?', choices=[('S', 'Si'), ('N', 'No')])
    original = fields.BooleanField('&iquest; El dise&ntilde;o de aquel proyecto es original ? ') 
    nuevouser = fields.TextField('Opcional: Deseas recibir futura informacion sobre Madeer ? Escribe tu correo') 



class Survey2Form(Form):
    publicar = fields.RadioField('&iquest; Consideras que existen dificultades para promover y publicitar tus dise&ntilde;os a escala Nacional ?',
        choices=[('S', 'Si'), ('N', 'No'), ('O','No aplica')], validators = [Required()])
    internacional = fields.RadioField('&iquest; Has publicado algun dise&ntilde;o en alg&uacute;n medio o blog Internacional ?',
        choices=[('S', 'Si'), ('N', 'No'), ('O','No aplica')], validators = [Required()])
    beneficios = fields.RadioField('&iquest; Qu&eacute; beneficio consideras de mayor importancia al lograr ser publicado ?', choices=[
        ('Reputacion', 'Potenciar perfil profesional'),
        ('NuevaForma', 'Divulgar nueva forma de resolver un problema'),
        ('Clientes', 'Alcanzar nuevos clientes')], validators=[Required()])
    tipo = fields.RadioField('Por favor, selecciona en que area del dise&ntilde;o se enfoca tu trabajo :', choices=[
        ('Grafico', 'Dise&ntilde;o Gr&aacute;fico'),
        ('Industrial', 'Dise&ntilde;o industrial'),
        ('Arq', 'Arquitectura'),
	('Web', 'Dise&ntilde;o Web'),
	('Arte', 'Arte'),
	('O', 'Otro')], validators=[Required()])
    plataforma = fields.TextField('&iquest; Cual plataforma web existente consideras relevante para tu &aacute;rea? (Anota la URL) ')


class Survey3Form(Form):

    importancia = fields.RadioField('&iquest; Qu&eacute; tan importantes resultan para ti o tu equipo los proyectos en madera ?',
        choices=[('Muy', 'Muy Importante'), ('Alta', 'Importante'), ('Media','De mediana importancia'), ('Baja','Baja importancia'), ('Nula','Nula / No aplica')], validators = [Required()])
    potenciar = fields.RadioField('&iquest; Qu&eacute; factores consideras que ayudarian a potenciar el uso de la madera como elemento constructivo ?', choices=[
        ('Diseno', 'Mas dise&ntilde;os eficientes disponibles'),
        ('Costo', 'Menor costo del material'),
        ('Conocimiento', 'Mayor conocimiento especializado'),
        ('Valor', 'Mayor valor agregado del producto / Innovaci&oacute;n')], validators=[Required()])
    frecuencia = fields.RadioField('&iquest; Qu&eacute; tan frecuente es el uso de la madera en tu ciudad ?',
        choices=[('Muy', 'Muy Frecuente'), ('Alta', 'Frecuente'), ('Media','Regular'), ('Baja','No muy com&uacute;n'), ('Nula','Virtualmente nula')], validators = [Required()])
    ciudad = fields.TextField('Opcional: Nombre de la ciudad')


class Survey4Form(Form):
    costos = fields.RadioField('&iquest; Esta usted al tanto de los costos materiales de un proyecto ?',
        choices=[('S', 'Si'), ('N', 'No')], validators = [Required()])
    conforme = fields.RadioField('&iquest; Esta conforme con la difusi&oacute;n actual de su proyecto ?',
        choices=[('S', 'Si'), ('N', 'No')], validators = [Required()])
    participar = fields.RadioField('&iquest; Ha participado usted en iniciativas externas como concursos, fondos y procesos de selecci&oacute;n para potenciar su proyecto ? ', choices=[('S', 'Si'), ('N', 'No')], validators = [Required()])
    difusion = fields.RadioField('&iquest; Es relevante para su proyecto establecer estrategias de difusi&oacute;n ?',
        choices=[('S', 'Si'), ('N', 'No')], validators = [Required()])



